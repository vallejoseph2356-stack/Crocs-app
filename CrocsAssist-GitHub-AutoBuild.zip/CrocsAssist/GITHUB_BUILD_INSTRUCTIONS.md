# Build CrocsAssist APK without Android Studio

You can build the APK entirely on GitHub from a phone or computer.

## 1. Create a GitHub repository
1. Sign in at github.com.
2. Tap **+** → **New repository**.
3. Name it `CrocsAssist`.
4. Choose **Private** if you do not want the project public.
5. Create the repository.

## 2. Upload the project files
Upload the **contents inside the CrocsAssist folder** to the root of the repository.

Important: the repository root should contain:
- `app/`
- `.github/`
- `build.gradle`
- `settings.gradle`

Do not upload the outer `CrocsAssist` folder as an extra nested directory.

## 3. Let GitHub build it
The included workflow `.github/workflows/build-apk.yml` automatically runs after the files are committed to `main` or `master`.

You can also run it manually:
1. Open the repository.
2. Tap **Actions**.
3. Select **Build Android APK**.
4. Tap **Run workflow**.

## 4. Download the APK
After the build has a green check mark:
1. Open that workflow run.
2. Scroll to **Artifacts**.
3. Tap **CrocsAssist-APK**.
4. GitHub downloads an artifact ZIP. Extract it.
5. Inside is `CrocsAssist.apk`.

## 5. Install on Android
Open `CrocsAssist.apk` on your Android device. Android may ask you to allow installs from your browser or file manager. Enable that permission only for the app you are using to open the APK, then continue installation.

This is a debug APK intended for personal testing. Android may warn that the app is from an unknown source because it is not from Google Play.
