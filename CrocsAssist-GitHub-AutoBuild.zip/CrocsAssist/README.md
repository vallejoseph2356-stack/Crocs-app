# Crocs Assist (Android)

Personal shopping assistant for crocs.com.

## What it does
- Opens a Crocs product page inside the app.
- Lets you enter the visible size text (for example `M10/W12`).
- Re-checks the loaded page every 12 seconds while the app is open.
- If the size and an enabled “Add to Bag/Cart” button are present, it alerts you.
- Optional: presses “Add to Bag” for you.
- You still review and submit checkout/payment yourself.

## What it intentionally does NOT do
- No CAPTCHA solving or bypass.
- No anti-bot/proxy/fingerprint evasion.
- No automatic final order submission.
- No bypassing item limits.

## Build
Open this folder in Android Studio, let Gradle sync, then choose **Build > Build APK(s)**.
The debug APK will normally appear under `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
Crocs can change its page markup at any time, so the size/button detection may need updating. The app also depends on the site permitting normal WebView access.
